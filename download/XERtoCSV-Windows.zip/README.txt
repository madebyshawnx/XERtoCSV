﻿XER to CSV Converter
====================

What it does:
Converts Primavera P6 .xer files into CSV files. For each .xer file it creates
a folder containing one CSV per table, plus a master Excel workbook (.xlsx) that
holds every table on its own tab.

How to use:
1. Double-click XERtoCSV-Windows.exe to open the app.
2. Choose the folder or files you want to convert.
3. Choose an output folder for the results.
4. Click Convert.

First-time note:
If Windows shows a blue box that says "Windows protected your PC," click
"More info" and then click "Run anyway." This is normal for a new app that does
not have a paid signing certificate.
